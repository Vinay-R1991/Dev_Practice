package com.example.Probe;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/probe")
public class ProbeController {
	@PostMapping("/navigate")
	public ResponseEntity<ProbeSummary> navigate(@RequestBody ProbeCommandRequest request){
		ProbeService service = new ProbeService(request);
		return ResponseEntity.ok(service.executeCommands());
	}

}
