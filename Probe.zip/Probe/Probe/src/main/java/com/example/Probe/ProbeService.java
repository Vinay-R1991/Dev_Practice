package com.example.Probe;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;

import javax.print.attribute.standard.PresentationDirection;

public class ProbeService {
	
	
	private final Set<Coordinate> visited = new LinkedHashSet<>();
	private final Set<Coordinate> obstacles;
	private final int gridWidth;
	private final int gridHeight;
	private Coordinate current;
	private Direction direction;
	private final List<String> commands;
	
	ProbeService(ProbeCommandRequest req){
		this.gridWidth = req.gridWidth();
		this.gridHeight = req.gridHeight();
		this.current = new Coordinate(req.startX(), req.startY());
		this.direction = Direction.valueOf(req.facing());
		this.commands = req.safeCommands();
		this.obstacles = new HashSet<>();
		for(List<Integer> obs : req.obstacles()) {
			obstacles.add(new Coordinate(obs.get(0), obs.get(1)));
		}
		visited.add(new Coordinate(current.x(), current.y()));
	}
	
	ProbeSummary executeCommands() {
		for(String cmdStr : commands) {
			Command cmd = Command.valueOf(cmdStr);
			if(cmd == Command.TURN_LEFT) direction = direction.left();
			else if(cmd == Command.TURN_RIGHT) direction = direction.right();
			else move(cmd == Command.MOVE_FORWARD);
		}
		return new ProbeSummary(current, direction, visited);
	}
	
	private void move(boolean forward) {
		int dx = direction.dx * (forward ? 1 : -1);
		int dy = direction.dy * (forward ? 1 : -1);
		Coordinate next = new Coordinate(current.x() + dx, current.y() + dy);
		if(isWithinGrid(next) && !obstacles.contains(next)) {
			current = next;
			visited.add(new Coordinate(current.x(), current.y()));
		}
	}
	
	private boolean isWithinGrid(Coordinate coord) {
		return coord.x() >= 0 && coord.x() < gridWidth && coord.y() >=0 && coord.y() < gridHeight;
	}
	

}

record ProbeCommandRequest(int startX, int startY, String facing, List<String> commands, int gridWidth, int gridHeight, List<List<Integer>> obstacles) {
	public List<String> safeCommands(){
		return commands == null ? new ArrayList<>() : commands;
	}
}

record ProbeSummary(Coordinate finalPosition, Direction direction, Set<Coordinate> visited) {}

record Coordinate(int x, int y) {
	@Override public boolean equals(Object o) {
		return o instanceof Coordinate c && c.x == x && c.y == y;
	}
	
	@Override public int hashCode() {
		return Objects.hash(x, y);
	}
	@Override public String toString() {
		return "(" + x + "," + y + ")";
	}
		
}
enum Direction {
	NORTH(0, 1), EAST(1, 0), SOUTH(0, -1), WEST(-1, 0);
	final int dx, dy;
	Direction(int dx, int dy){
		this.dx = dx;
		this.dy = dy;
	}
	Direction left() {
		return values()[(ordinal() + 3) % 4];
	}
	Direction right() {
		return values()[(ordinal() + 1) % 4];
	}
}

enum Command {
	MOVE_FORWARD, MOVE_BACKWARD, TURN_LEFT, TURN_RIGHT
}
