package com.example.Probe;

import java.util.List;


import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class ProbeApplicationTest{

	@Test
	void testSimpleNavigationObstacles() {
		ProbeCommandRequest request = new ProbeCommandRequest(
				0, 0, "NORTH",
				List.of("MOVE_FORWARD", "TURN_RIGHT", "MOVE_FORWARD"),
				5, 5,
				List.of()
				);
		ProbeService service = new ProbeService(request);
		ProbeSummary result = service.executeCommands();
		
		assertEquals(new Coordinate(1, 1), result.finalPosition());
		assertEquals(Direction.EAST, result.direction());
		assertTrue(result.visited().contains(new Coordinate(0, 0)));
		assertTrue(result.visited().contains(new Coordinate(0, 1)));
		assertTrue(result.visited().contains(new Coordinate(1, 1)));
	}
	@Test
	void testWithObstacleAvoidance() {
		ProbeCommandRequest request = new ProbeCommandRequest(0, 0, "NORTH",List.of("MOVE_FORWARD", "MOVE_FORWARD"), 5, 5, List.of(List.of(0, 1)));
		ProbeService service = new ProbeService(request);
		ProbeSummary result = service.executeCommands();
		assertEquals(new Coordinate(0, 0), result.finalPosition());
		assertEquals(Direction.NORTH, result.direction());
		assertEquals(1,result.visited().size());
		
	}
	@Test
	void testEdgeBoundaryHandling() {
		ProbeCommandRequest request = new ProbeCommandRequest(
				0, 0, "SOUTH",
				List.of("MOVE_FORWARD", "TURN_LEFT", "MOVE_FORWARD"),
				5, 5,
				List.of()
				);
		ProbeService service = new ProbeService(request);
		ProbeSummary result = service.executeCommands();
		
		assertEquals(new Coordinate(0, 0), result.finalPosition());
		assertEquals(Direction.EAST, result.direction());
		assertTrue(result.visited().contains(new Coordinate(0, 0)));
		
	}


}
